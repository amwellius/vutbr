from django.urls import path, include
from .views import home_list, about

#URLs used for NetworkScanner urls.py
app_name = "home"
urlpatterns = [
    path('', home_list),
    path('about/', about),
]