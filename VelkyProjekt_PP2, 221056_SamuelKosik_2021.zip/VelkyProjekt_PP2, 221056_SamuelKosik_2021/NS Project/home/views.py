from django.shortcuts import render, redirect, get_object_or_404

#Rendering home page extended with JavaSkripts
def home_list(request, *args, **kwargs):
    data = 1
    context = {
        "data" : data
    }
    return render(request, "home_base.html", context)

def about(request, *args, **kwargs):
    data = 1
    context = {
        "data" : data
    }
    return render(request, "about.html", context)



