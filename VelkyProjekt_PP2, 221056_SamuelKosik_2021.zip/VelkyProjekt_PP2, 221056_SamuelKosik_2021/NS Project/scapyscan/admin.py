from django.contrib import admin
from .models import ScapyScan


admin.site.register(ScapyScan)