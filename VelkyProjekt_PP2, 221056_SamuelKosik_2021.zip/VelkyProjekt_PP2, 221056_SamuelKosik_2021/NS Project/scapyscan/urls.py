from django.urls import path
from .views import scapyscan_list, scapyscan_start

#These URLs are used
app_name = "scapyscan"
urlpatterns = [
    path('list/', scapyscan_list),
    path('', scapyscan_start),
]