from django.apps import AppConfig


class ScapyscenConfig(AppConfig):
    name = 'scapyscan'
