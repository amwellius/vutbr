from django import forms 
from .models import ScapyScan


#Particular tests
def space_test(x):
    y = x.isspace()
    y = 1
    return y

def digit_test(x):
    y = x.isdigit()
    return y

def stop_test(x):
    y = x.count('.')
    return y

def slash_test(x):
    y = x.count('/')
    return y
        
#Main form
class ScapyScanForm(forms.ModelForm):
    ip = forms.CharField(required = True, max_length = 21, initial="192.168.1.0/24")

    #Checking validation of value in ip
    def clean_ip(self):
        data = self.cleaned_data.get('ip')
        
        #Slash Checking
        if (slash_test(data) < 1 ):
            raise forms.ValidationError('Use "/" for port !')
        elif (slash_test(data) > 1 ):
            raise forms.ValidationError('Use only one "/" !')
        #Stop Checking
        if (stop_test(data) != 3 ):
            raise forms.ValidationError('IPv4 consists of 3 stops !')
        #Digit Checking
        if (digit_test(data) == True ):
            raise forms.ValidationError('Is it IP Address? Check it once again, please !')
        #Space Checking
        elif (space_test(data) == 1 ):
            data = data.replace(" ", "")
        else:
            raise forms.ValidationError('Something went wrong :(')
        #elif not  xtest(data, False):
         #   raise forms.ValidationError('xTest Error msg')

        return data

    class Meta:
        model = ScapyScan
        fields = [
            'ip',                        
        ]