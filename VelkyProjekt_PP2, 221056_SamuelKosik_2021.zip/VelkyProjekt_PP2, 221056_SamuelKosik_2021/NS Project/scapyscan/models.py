from django.db import models


#Models for Django
class ScapyScan(models.Model):
    ip  = models.CharField(max_length=21) 
    
    class Meta:
        app_label = 'scapyscan'
    
    def __str__(self):
        return "%s, %s" % (self.pk, self.ip)

