from .models import ScapyScan
from .forms import ScapyScanForm
from django.shortcuts import render, redirect
from .scanning import Scanning

#Rendering the main scapy scanner page
def scapyscan_start(request):
    form = ScapyScanForm(request.POST or None)
    if form.is_valid():
        form.save()
        form = ScapyScanForm()
        return redirect('/scapyscan/list')        
    context = {
        'form' : form
    }
    return render(request, "scapyscan/start.html",context)

#Rendering list of scanned IPs
def scapyscan_list(request, *args, **kwargs):
    data = ScapyScan.objects.all()
    target_ip = data[len(data)-1].ip
    ipaddress, macaddress = Scanning(data[len(data)-1].ip)
    zipped_data = zip(ipaddress, macaddress)
    context = {
        "zipped" : zipped_data,
        "data": data,
        "target_ip" : target_ip,
        "ipaddress": ipaddress,
        "macaddress" : macaddress,
    }
    return render(request, "scapyscan/list.html", context)



